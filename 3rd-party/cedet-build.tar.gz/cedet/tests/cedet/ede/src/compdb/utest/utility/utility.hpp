#ifndef UTILITY_HPP
#define UTILITY_HPP

static const char EOL = '\n';

#endif
