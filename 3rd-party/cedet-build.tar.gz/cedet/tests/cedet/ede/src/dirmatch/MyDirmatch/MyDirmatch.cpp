// A CPP file that matches the host directory.
