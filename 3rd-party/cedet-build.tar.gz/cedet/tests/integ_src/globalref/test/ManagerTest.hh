#pragma once

#include "Util.hh"

//
// This fcn uses the namespaces used in the test, but should not be
// a search destination.
//
namespace play { namespace test {
    class ManagerTest {
    public:
      ManagerTest();
    };
}}

